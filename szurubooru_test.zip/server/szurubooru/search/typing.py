from typing import Any, Callable

SaColumn = Any
SaQuery = Any
SaQueryFactory = Callable[[], SaQuery]
