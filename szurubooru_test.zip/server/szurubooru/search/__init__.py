import szurubooru.search.configs
from szurubooru.search.executor import Executor
