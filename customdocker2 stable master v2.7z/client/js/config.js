"use strict";

const config = require("./.config.autogen.json");
module.exports = config;
