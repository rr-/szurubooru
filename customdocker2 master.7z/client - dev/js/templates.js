"use strict";

module.exports = require("./.templates.autogen.js");
